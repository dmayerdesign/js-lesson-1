FUNCTION
From Wikipedia: some code that performs a specific task, packaged as a unit. This unit can then be used in programs wherever that particular task should be performed.

FUNCTION DECLARATION
Writing a function such that we can use it in other parts of our code (as opposed to INLINING a function, which is writing a function that can only be used in one part of our code).

FUNCTION PARAMETERS
Variables that are the inputs to a function.

FUNCTION RETURN VALUE
A variable that is the output of a function.

FUNCTION INVOCATION
"Calling" or executing a function.

VARIABLE DECLARATION
Naming a variable, but not necessarily giving it a value yet.

VARIABLE INITIALIZATION
Setting a variable to its very first value.

VARIABLE ASSIGNMENT
Setting a variable to some value.


